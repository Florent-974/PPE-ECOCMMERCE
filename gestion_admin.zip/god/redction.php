<?php

	$db = new PDO("mysql:host=localhost;dbname=administration;charset=utf8", "root", "btssio");

    if(isset($_GET['confirme']) AND !empty($_GET['confirme'])) {
        $confirme = (int) $_GET['confirme'];
    
        $req = $db->prepare('UPDATE membres SET confirme = 1 WHERE id = ?');
        $req->execute(array($confirme));
    }

    if(isset($_GET['supprime']) AND !empty($_GET['supprime'])) {
        $supprime= (int) $_GET['supprime'];
    
        $req = $db->prepare('DELETE FROM membres WHERE id = ?');
        $req->execute(array($supprime));
    }


$membres = $db->query('SELECT * FROM membres ORDER BY id DESC LIMIT 0,5');


	
?>

<!DOCTYPE html>
<html>
<head>
            <meta charset="utf-8" />
            <title>Administration</title>
</head>
<body>
    <h3>Compte des clients :</h3>
        <ul>
            <?php while($m = $membres->fetch()) { ?>
            <li><?= $m['id'] ?> : <?= $m['pseudo'] ?><?php if($m['confirme'] == 0) {  ?> - <a href=
            "redction.php?confirme=<?= $m[ 'id' ] ?>">Confirmer</a><?php } ?> - <a href="redction.php?supprime=<?=
                $m['id'] ?>">Supprimer</a></li>
            <?php } ?>
        </ul>



</body>
</html>
