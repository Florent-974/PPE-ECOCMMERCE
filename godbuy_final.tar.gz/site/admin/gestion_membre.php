<?php

	$db = new PDO("mysql:host=localhost;dbname=site;charset=utf8", "root", "");

    if(isset($_GET['confirme_email']) AND !empty($_GET['confirme_email'])) {
        $confirme = (int) $_GET['confirme_email'];
    
        $req = $db->prepare('UPDATE membre SET confirme_email = 1 WHERE id_membre = ?');
        $req->execute(array($confirme));
    }

    if(isset($_GET['supprime']) AND !empty($_GET['supprime'])) {
        $supprime= (int) $_GET['supprime'];
    
        $req = $db->prepare('DELETE FROM membre WHERE id_membre = ?');
        $req->execute(array($supprime));
    }


$membres = $db->query('SELECT * FROM membre ORDER BY id DESC LIMIT 0,5');


	
?>

<!DOCTYPE html>
<html>
<head>
            <meta charset="utf-8" />
            <title>Administration</title>
</head>
<body>
    <h3>Compte des clients :</h3>
        <ul>
            <?php while($m = $membres->fetch()) { ?>
            <li><?= $m['id_membre'] ?> : <?= $m['pseudo'] ?> : <?= $m['mdp'] ?> : <?= $m['nom'] ?> : <?= $m['prenom'] ?> : <?= $m['email'] ?> : <?= $m['civilite'] ?> : <?= $m['ville'] ?> : <?= $m['code_postal'] ?> : <?= $m['adresse'] ?> : <?= $m['statut'] ?> :  <?php if($m['confirme_email'] == 0) {  ?> - <a href=
            "gestion_membre.php?confirme=<?= $m[ 'id_membre' ] ?>">Confirmer</a><?php } ?> - <a href="gestion_membre.php?supprime=<?=
                $m['id_membre'] ?>">Supprimer</a></li>
            <?php } ?>
        </ul>



</body>
</html>
