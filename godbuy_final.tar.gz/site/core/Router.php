<?php
//class global pas besoin d'etre instancier
class Router{

    /**
     * Permet de parser une url
     * @param $url a parser
     * @return tableau contenant les parametres
     */

    static function parse($url){
        $url = trim($url,'/');
        $param = explode('/',$url);
        print_r($param)

    }

   
}

?>