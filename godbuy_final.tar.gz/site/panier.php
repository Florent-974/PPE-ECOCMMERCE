<div style="clear: both"></div>
        <h3 class="title2">Panier</h3>
        <div class="table-responsive">
            <table class="table table-bordered">
            <tr>
                <th width="30%">Nom du produit</th>
                <th width="10%">Quantité</th>
                <th width="13%">Prix</th>
                <th width="10%">Prix total</th>
                <th width="17%">Supprimer produit</th>
            </tr>

            <?php
                if(!empty($_SESSION["cart"])){
                    $total = 0;
                    foreach ($_SESSION["cart"] as $key => $value) {
                        ?>
                        <tr>
                            <td><?php echo $value["item_name"]; ?></td>
                            <td><?php echo $value["item_quantity"]; ?></td>
                            <td><?php echo $value["product_prix"]; ?> €</td>
                            <td>
                                <?php echo number_format($value["item_quantity"] * $value["product_prix"], 2); ?> €</td>
                            <td><a href="index.php?action=delete&id=<?php echo $value["product_id"]; ?>"><span
                                        class="text-danger">Supprimer produit</span></a></td>

                        </tr>
                        <?php
                        $total = $total + ($value["item_quantity"] * $value["product_prix"]);
                    }
                        ?>
                        <tr>
                            <td colspan="3" align="right">Totale</td>
                            <th align="right"><?php echo number_format($total, 2); ?>  €</th>
                            <td></td>
                        </tr>
                        <?php
                    }
                ?>
            </table>
        </div>

      
    </div>