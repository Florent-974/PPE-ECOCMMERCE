<!Doctype html>
<html>
    <head>
        <title>Mon Site</title>
        <link rel="stylesheet" href="<?php echo RACINE_SITE; ?>css/style.css">
    </head>
    <body>    
        <header>
            <div class="conteneur">
                <div>
                    <a class="navbar-brand" href="index.php"><img src="webroot/img/logo.png" width="80" height="80" alt=""></a>
                </div>
                <nav>
                    <a href="<?php echo RACINE_SITE; ?>inscription.php">Inscription</a>
                    <a href="<?php echo RACINE_SITE; ?>connexion.php">Connexion</a>
                    <a href="<?php echo RACINE_SITE; ?>connexion.php">Jeux</a>
                    <a href="<?php echo RACINE_SITE; ?>connexion.php">Console</a>
                    <a href="<?php echo RACINE_SITE; ?>connexion.php">Accessoire</a>
                    <a href="<?php echo RACINE_SITE; ?>connexion.php">Espace client</a>
                </nav>
            </div>
        </header>
        <section>
            <div class="conteneur">